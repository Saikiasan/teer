import json
import requests
from collections import Counter, defaultdict
from datetime import datetime

# Fetch the data from the API
def fetch_data(url):
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        raise ValueError(f"Failed to fetch data. HTTP Status Code: {response.status_code}")

# Analyze the frequency of numbers in the dataset
def analyze_frequency(data, round_key):
    numbers = []
    for entry in data:
        try:
            numbers.append(int(entry[round_key]))
        except ValueError:
            print(f"Invalid number format: {entry[round_key]}")
    return Counter(numbers)

# Analyze sequence patterns
def analyze_sequence_patterns(data, round_key):
    sequence_map = defaultdict(list)
    for i in range(len(data) - 1):
        try:
            current = int(data[i][round_key])
            next_val = int(data[i + 1][round_key])
            sequence_map[current].append(next_val)
        except ValueError:
            continue
    return {k: Counter(v).most_common(1)[0][0] for k, v in sequence_map.items() if v}

# Analyze day-of-week patterns
def analyze_day_patterns(data, round_key):
    day_map = defaultdict(list)
    for entry in data:
        try:
            date_obj = datetime.strptime(entry['date'], '%Y-%m-%d')
            day_of_week = date_obj.weekday()  # Monday = 0, Sunday = 6
            number = int(entry[round_key])
            day_map[day_of_week].append(number)
        except ValueError:
            continue
    return {day: Counter(numbers).most_common(1)[0][0] for day, numbers in day_map.items() if numbers}

# Predict the next number based on frequency, sequence, and patterns
def predict_next(frequency_data, sequence_data, day_data, last_number, current_day):
    predictions = []

    # Frequency-based prediction
    if frequency_data:
        predictions.append(frequency_data.most_common(1)[0][0])

    # Sequence-based prediction
    if last_number in sequence_data:
        predictions.append(sequence_data[last_number])

    # Day-of-week-based prediction
    if current_day in day_data:
        predictions.append(day_data[current_day])

    # Combine predictions (most frequent among them)
    combined = Counter(predictions)
    return combined.most_common(1)[0][0] if combined else None

# Main function
def main():
    url = "https://admin.shillongteerground.com/teer/api/results/"
    data = fetch_data(url)

    # Analyze frequency, sequence patterns, and day-of-week patterns
    first_round_frequency = analyze_frequency(data, 'first_round')
    second_round_frequency = analyze_frequency(data, 'second_round')

    first_round_sequence = analyze_sequence_patterns(data, 'first_round')
    second_round_sequence = analyze_sequence_patterns(data, 'second_round')

    first_round_day = analyze_day_patterns(data, 'first_round')
    second_round_day = analyze_day_patterns(data, 'second_round')

    # Get last numbers and today's day of the week
    last_first_round = int(data[-1]['first_round'])
    last_second_round = int(data[-1]['second_round'])
    current_day = datetime.now().weekday()

    # Predict next numbers
    next_first_round = predict_next(first_round_frequency, first_round_sequence, first_round_day, last_first_round, current_day)
    next_second_round = predict_next(second_round_frequency, second_round_sequence, second_round_day, last_second_round, current_day)

    print("Prediction for next day's numbers with pattern recognition:")
    print(f"First Round: {next_first_round}")
    print(f"Second Round: {next_second_round}")

if __name__ == "__main__":
    main()
