import requests
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import numpy as np
from datetime import datetime

# Fetch data from the API
def fetch_data(url):
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        raise ValueError(f"Failed to fetch data. HTTP Status Code: {response.status_code}")

# Prepare the dataset for ML
def prepare_dataset(data):
    df = pd.DataFrame(data)
    df['date'] = pd.to_datetime(df['date'])
    df['day_of_week'] = df['date'].dt.weekday  # Monday = 0, Sunday = 6

    # Convert rounds to integers, handle invalid data
    df['first_round'] = pd.to_numeric(df['first_round'], errors='coerce')
    df['second_round'] = pd.to_numeric(df['second_round'], errors='coerce')

    # Shift columns to create target values (next day's numbers)
    df['next_first_round'] = df['first_round'].shift(-1)
    df['next_second_round'] = df['second_round'].shift(-1)

    # Drop rows with NaN values (last row and invalid entries)
    df = df.dropna()

    return df

# Train ML models
def train_models(df):
    features = ['first_round', 'second_round', 'day_of_week']
    target_first = 'next_first_round'
    target_second = 'next_second_round'

    # Split the dataset for training and testing
    X = df[features]
    y_first = df[target_first]
    y_second = df[target_second]

    X_train, X_test, y_train_first, y_test_first = train_test_split(X, y_first, test_size=0.2, random_state=42)
    X_train, X_test, y_train_second, y_test_second = train_test_split(X, y_second, test_size=0.2, random_state=42)

    # Train Random Forest models
    model_first = RandomForestClassifier(n_estimators=100, random_state=42)
    model_second = RandomForestClassifier(n_estimators=100, random_state=42)

    model_first.fit(X_train, y_train_first)
    model_second.fit(X_train, y_train_second)

    # Evaluate models
    y_pred_first = model_first.predict(X_test)
    y_pred_second = model_second.predict(X_test)

    print("Accuracy for First Round Prediction:", accuracy_score(y_test_first, y_pred_first))
    print("Accuracy for Second Round Prediction:", accuracy_score(y_test_second, y_pred_second))

    return model_first, model_second

def predict_next_day(model_first, model_second, current_data):
    features = ['first_round', 'second_round', 'day_of_week']
    
    # Extract values from current_data for the features
    current_values = [current_data[feature] for feature in features]
    
    # Reshaping to 2D array (1 row, multiple features)
    current_values = np.array(current_values).reshape(1, -1)
    
    next_first = model_first.predict(current_values)[0]
    next_second = model_second.predict(current_values)[0]
    
    return next_first, next_second




# Main function
def main():
    url = "https://admin.shillongteerground.com/teer/api/results/"
    data = fetch_data(url)

    # Prepare dataset
    df = prepare_dataset(data)

    # Train models
    model_first, model_second = train_models(df)

    # Get current day's data
    last_entry = df.iloc[-1]
    current_data = last_entry.to_dict()

    # Predict next day's numbers
    next_first_round, next_second_round = predict_next_day(model_first, model_second, current_data)

    print("Prediction for next day's numbers using ML:")
    print(f"First Round: {next_first_round}")
    print(f"Second Round: {next_second_round}")

if __name__ == "__main__":
    main()
