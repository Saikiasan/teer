import { navigation } from "./htmlWorker.js";

const main = $('.main');
main.append(navigation("Ankit"))