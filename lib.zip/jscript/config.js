const CONFIG = {
  API_URL: "https://admin.shillongteerground.com/teer/api/results/",
};
