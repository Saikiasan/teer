import requests
import pandas as pd

# Fetch JSON data
url = "https://admin.shillongteerground.com/teer/api/results"
response = requests.get(url)

if response.status_code == 200:
    data = response.json()  # Parse JSON
    print("Data fetched successfully!")
else:
    print(f"Failed to fetch data. HTTP Status Code: {response.status_code}")
    exit()

# Normalize JSON
df = pd.json_normalize(data)

# Save as CSV
df.to_csv("teer_results.csv", index=False)
print("Data saved as 'teer_results.csv'")
