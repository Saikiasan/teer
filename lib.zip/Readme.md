# TEER - A luck based game
In this game, the users place a guessed number with the system of purchasing a ticket which will be used to obtain the sum of money to be given to the user if they have successfukky guessed the right number.

This is a complete game with random + a fair means of game playing.

## The game rules
The game rules are simple.
> The player/ user has to place a guessed number with a ticket based sustem where there would be three types/ ranks of ticket:
namely :
- gold - 20
- silver - 10
- bromze - 5


requirements:
- get details of the player
- place the teer
- check details of the users who won

- get maximm number of number bets
- get minimum

- phone number
- upi / bank
- name
- ticket
- guessed numbers